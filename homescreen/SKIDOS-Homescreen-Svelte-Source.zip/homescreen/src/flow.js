export const MOTION = Object.freeze({ tab: 220, page: 280, ip: 250, focus: 240, hide: 200, show: 250, idle: 2000 });

export function rowItems(items, limit = 15) {
  const count = Math.max(1, Math.floor(Number(limit) || 15));
  return { items: items.slice(0, count), hasMore: items.length > count };
}

export function nearestFocus(offset, stride = 464, count = 4) {
  return Math.max(0, Math.min(count - 1, Math.round(offset / stride)));
}

// Both controls respond only to vertical page activity, including momentum.
export function createChromeController({ setVisible, delay = MOTION.idle, schedule = setTimeout, cancel = clearTimeout }) {
  let timer;
  let suspended = false;
  function clear() { if (timer !== undefined) cancel(timer); timer = undefined; }
  function activity() {
    if (suspended) return;
    clear(); setVisible(false);
    timer = schedule(() => { timer = undefined; if (!suspended) setVisible(true); }, delay);
  }
  return {
    activity,
    suspend() { suspended = true; clear(); },
    resume() { suspended = false; clear(); setVisible(true); },
    destroy() { suspended = true; clear(); }
  };
}

export function dragScroll(node, { scale = () => 1, axis = 'x' } = {}) {
  let pointer = null, moved = false, suppressUntil = 0;
  const down = e => {
    if (e.pointerType !== 'mouse' || e.button !== 0) return;
    pointer = { id: e.pointerId, x: e.clientX, y: e.clientY, scroll: axis === 'x' ? node.scrollLeft : node.scrollTop };
    moved = false;
  };
  const move = e => {
    if (!pointer || e.pointerId !== pointer.id) return;
    const dx = e.clientX - pointer.x, dy = e.clientY - pointer.y;
    if (!moved && Math.abs(axis === 'x' ? dx : dy) < 7) return;
    if (axis === 'x' && !moved && Math.abs(dy) > Math.abs(dx)) { pointer = null; return; }
    moved = true; node.classList.add('dragging');
    e.preventDefault();
    if (axis === 'x') node.scrollLeft = pointer.scroll - dx / scale();
    else node.scrollTop = pointer.scroll - dy / scale();
  };
  const up = () => { if (moved) suppressUntil = performance.now() + 200; pointer = null; moved = false; node.classList.remove('dragging'); };
  const click = e => { if (performance.now() < suppressUntil) { e.preventDefault(); e.stopImmediatePropagation(); } };
  node.addEventListener('pointerdown', down);
  node.addEventListener('click', click, true);
  window.addEventListener('pointermove', move, { passive: false });
  window.addEventListener('pointerup', up); window.addEventListener('pointercancel', up);
  return { destroy() { node.removeEventListener('pointerdown', down); node.removeEventListener('click', click, true); window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); window.removeEventListener('pointercancel', up); } };
}

export function focusDialog(node) {
  const previous = document.activeElement;
  queueMicrotask(() => node.querySelector('button')?.focus({ preventScroll: true }));
  const key = e => {
    if (e.key !== 'Tab') return;
    const controls = [...node.querySelectorAll('button:not(:disabled),select,a[href],[tabindex="0"]')].filter(x => x.offsetParent !== null);
    const first = controls[0], last = controls.at(-1);
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last?.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first?.focus(); }
  };
  node.addEventListener('keydown', key);
  return { destroy() { node.removeEventListener('keydown', key); if (previous?.isConnected) requestAnimationFrame(() => previous.focus({ preventScroll: true })); } };
}
