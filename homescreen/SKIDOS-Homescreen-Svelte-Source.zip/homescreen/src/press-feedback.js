export const PRESS_FEEDBACK = Object.freeze({ offset: 8, down: 80, return: 140, dragThreshold: 7 });

// Delegated feedback leaves layout, tile fitting and carousel focus transforms intact.
export function pressFeedback(root, { reduced = () => false, offset = () => PRESS_FEEDBACK.offset } = {}) {
  let gesture = null;
  let pending = null;
  const replaying = new WeakSet();
  const records = new Map();
  const buttonFor = target => target?.closest?.('button');
  const available = button => button?.isConnected && !button.disabled && !button.closest('[inert]') && root.contains(button);
  function record(button) {
    if (!records.has(button)) records.set(button, { animation: null, down: null, original: button.style.translate });
    return records.get(button);
  }
  function animate(button, y, duration) {
    const state = record(button);
    const from = getComputedStyle(button).translate;
    state.animation?.cancel();
    button.style.translate = `0 ${y}px`;
    button.dataset.press = y ? 'pressed' : 'returning';
    state.animation = button.animate([{ translate: from === 'none' ? '0 0' : from }, { translate: `0 ${y}px` }], { duration, easing: 'ease-out' });
    return state.animation.finished.catch(() => {});
  }
  function down(button) {
    if (!available(button) || reduced()) return;
    const state = record(button);
    state.down = animate(button, offset(), PRESS_FEEDBACK.down);
  }
  function restore(button, immediate = false) {
    const state = records.get(button);
    if (!state) return Promise.resolve();
    return animate(button, 0, immediate || reduced() ? 0 : PRESS_FEEDBACK.return).then(() => {
      if (button.dataset.press === 'returning') {
        button.style.translate = state.original;
        delete button.dataset.press;
      }
    });
  }
  function cancelGesture() {
    if (gesture) { gesture.cancelled = true; restore(gesture.button); }
  }
  const pointerdown = event => {
    if (event.button !== 0 || pending) return;
    const button = buttonFor(event.target);
    if (!available(button)) return;
    cancelGesture();
    gesture = { button, x: event.clientX, y: event.clientY, cancelled: false, up: false };
    down(button);
  };
  const pointermove = event => {
    if (!gesture || gesture.up || gesture.cancelled) return;
    if (Math.hypot(event.clientX - gesture.x, event.clientY - gesture.y) > PRESS_FEEDBACK.dragThreshold) cancelGesture();
  };
  const pointerup = event => {
    if (!gesture) return;
    gesture.up = true;
    // A valid native click owns the complete down/up cycle before activation.
    if (gesture.cancelled || buttonFor(event.target) !== gesture.button) restore(gesture.button);
  };
  const pointercancel = () => { cancelGesture(); gesture = null; };
  const scroll = () => { if (gesture && !gesture.up) cancelGesture(); };
  const keydown = event => {
    if (event.key === 'Escape') { pending = null; cancelGesture(); return; }
    if ((event.key === ' ' || event.key === 'Enter') && !event.repeat) down(buttonFor(event.target));
  };
  const visibility = () => {
    if (!document.hidden) return;
    pending = null;
    pointercancel();
    for (const button of records.keys()) restore(button, true);
  };
  const click = async event => {
    const button = buttonFor(event.target);
    if (!available(button) || replaying.has(button)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (pending) return;
    if (gesture?.button === button && gesture.cancelled) { gesture = null; return; }
    const token = {};
    pending = token;
    if (!reduced()) {
      let state = records.get(button);
      if (!state?.down || button.dataset.press !== 'pressed') { down(button); state = records.get(button); }
      await state.down;
      await restore(button);
    }
    if (pending !== token) return;
    pending = null; gesture = null;
    if (!available(button)) return;
    replaying.add(button);
    button.click();
    replaying.delete(button);
  };
  root.addEventListener('pointerdown', pointerdown);
  root.addEventListener('click', click, true);
  root.addEventListener('keydown', keydown);
  document.addEventListener('visibilitychange', visibility);
  root.addEventListener('scroll', scroll, true);
  window.addEventListener('pointermove', pointermove);
  window.addEventListener('pointerup', pointerup);
  window.addEventListener('pointercancel', pointercancel);
  return { destroy() {
    pending = null;
    root.removeEventListener('pointerdown', pointerdown); root.removeEventListener('click', click, true);
    root.removeEventListener('keydown', keydown); document.removeEventListener('visibilitychange', visibility); root.removeEventListener('scroll', scroll, true);
    window.removeEventListener('pointermove', pointermove); window.removeEventListener('pointerup', pointerup); window.removeEventListener('pointercancel', pointercancel);
    for (const [button, state] of records) { state.animation?.cancel(); button.style.translate = state.original; delete button.dataset.press; }
    records.clear();
  } };
}
