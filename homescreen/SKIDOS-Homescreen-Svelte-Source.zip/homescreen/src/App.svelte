<script>
  import { onMount, tick } from 'svelte';
  import { fly } from 'svelte/transition';
  import { cubicOut } from 'svelte/easing';
  import Browse from './components/Browse.svelte';
  import Destination from './components/Destination.svelte';
  import assets from './generated-assets.js';
  import { backgrounds, devices, previewFor, sceneFor, tabs, themes } from './catalog.js';
  import { MOTION, createChromeController } from './flow.js';
  import { pressFeedback } from './press-feedback.js';

  const browseTabs = tabs.slice(0, -1);
  const iconPositions = [14.42, 32.99, 50.86, 68.36, 86.07];
  const tabColors = { Play: '#3b075b', Watch: '#8b0800', Learn: '#111075' };
  const rgb = color => `rgb(${color.r * 255} ${color.g * 255} ${color.b * 255})`;
  let device = $state('iPad');
  let active = $state('Home');
  let theme = $state('Morning');
  let chrome = $state(true);
  let reduced = $state(false);
  let scale = $state(1);
  let stack = $state.raw([]);
  let holder = $state();
  let stage = $state();
  let controller;
  let sequence = 0;
  let resize;
  const layout = $derived(devices[device]);
  const current = $derived(stack.at(-1));
  const home = $derived(backgrounds.find(item => item.name === 'Home / ' + theme + ' / Tablet / Idle'));
  const sceneColor = $derived(active === 'Home' ? rgb(home.fills[0].color) : tabColors[active]);
  const dockTheme = $derived((active === 'Home' ? theme : active).toLowerCase());

  function themeCss(shape, parent) {
    const factor = layout.width / 800;
    const x = ((parent?.x ?? 0) + shape.x - 720) * factor + layout.width / 2;
    const y = ((parent?.y ?? 0) + shape.y) * factor;
    const color = shape.fills?.[0]?.color;
    return `left:${x}px;top:${y}px;width:${shape.width * factor}px;height:${shape.height * factor}px;opacity:${parent?.opacity ?? shape.opacity ?? 1};background:${color ? rgb(color) : 'transparent'}`;
  }

  function open(destination) {
    stack = [...stack, { ...destination, key: ++sequence }];
    controller?.suspend();
  }

  function back() {
    if (!current) return;
    stack = stack.slice(0, -1);
    if (!stack.length) controller?.resume();
  }

  function selectTab(tab) {
    if (tab === 'Bites') {
      open({ type: 'bites', title: 'SKIDOS Bites' });
      return;
    }
    active = tab;
    controller?.resume();
  }

  function selectTile(card) {
    if (card.kind === 'IP' || card.kind === 'IP Shows') {
      const preview = previewFor(card);
      open({ type: 'ip', title: preview.name, preview });
      return;
    }
    const type = ({ Show: 'Show', Episode: 'Episode', Game: 'Game', 'IP Game': 'Game' })[card.kind];
    open({ type: 'content', title: card.label || card.title || type || 'Content' });
  }

  function selectAccount(type, title) {
    open({ type, title });
  }

  async function reset() {
    stack = [];
    active = 'Home';
    theme = 'Morning';
    controller?.suspend();
    await tick();
    stage?.querySelectorAll('.browse, .row-scroll').forEach(node => node.scrollTo(0, 0));
    requestAnimationFrame(() => { if (!current && !document.hidden) controller?.resume(); });
  }

  async function changeDevice() {
    await tick();
    resize?.();
  }

  async function fullscreen() {
    if (document.fullscreenElement) await document.exitFullscreen();
    else await holder?.requestFullscreen?.();
  }

  function onkeydown(event) {
    if (event.key !== 'Escape' || !current) return;
    event.preventDefault();
    back();
  }

  onMount(() => {
    controller = createChromeController({ setVisible: value => chrome = value });
    const media = matchMedia('(prefers-reduced-motion: reduce)');
    reduced = media.matches;
    const updateMotion = event => reduced = event.matches;
    media.addEventListener('change', updateMotion);
    resize = () => {
      if (holder) scale = Math.min(holder.clientWidth / layout.width, holder.clientHeight / layout.height);
    };
    const observer = new ResizeObserver(resize);
    observer.observe(holder);
    resize();
    const visibility = () => {
      if (document.hidden || current) controller.suspend();
      else controller.resume();
    };
    document.addEventListener('visibilitychange', visibility);
    return () => {
      controller.destroy();
      observer.disconnect();
      media.removeEventListener('change', updateMotion);
      document.removeEventListener('visibilitychange', visibility);
    };
  });
</script>

<svelte:window {onkeydown} />

<main class="shell">
  <header class="toolbar" aria-label="Preview controls">
    <div class="preview-title">
      <strong>Homescreen preview</strong>
      <span>{layout.width} × {layout.height} CSS px</span>
    </div>
    <div class="controls">
      <label>Device <select bind:value={device} onchange={changeDevice}>
        {#each Object.keys(devices) as preset}<option>{preset}</option>{/each}
      </select></label>
      <label>Home theme <select bind:value={theme}>
        {#each themes as option}<option>{option}</option>{/each}
      </select></label>
      <button onclick={reset}>Reset</button>
      <button onclick={fullscreen}>Full screen</button>
      <a href="../">Subscription preview</a>
    </div>
  </header>

  <div class="canvas" bind:this={holder}>
    <div class="device" bind:this={stage}
      use:pressFeedback={{ reduced: () => reduced, offset: () => device === 'iPhone' ? 4 : 5 }}
      style:width="{layout.width}px" style:height="{layout.height}px" style:transform="scale({scale})"
      style:--device-width="{layout.width}px" style:--inset="{layout.inset}px" style:--top="{layout.top}px"
      style:--body="{layout.body}px" style:--gap="{layout.gap}px" style:--row-gap="{layout.rowGap}px"
      style:--row-title="{layout.title}px" style:--fade="{layout.fade}px" style:--scene-color={sceneColor}
      style:--dock-bottom="{layout.dockBottom}px" style:--head-scale={layout.headerScale}
      style:--dock-scale={layout.dockScale} style:--label="{layout.label}px"
      data-device={device} data-active={active} data-chrome={chrome ? 'visible' : 'hidden'}>

      <div class="backdrop" aria-hidden="true">
        {#if active === 'Home'}
          {#each home.layers.filter(node => !node.name.includes('gradient')) as shape}
            {#if shape.children}
              {#each shape.children as star}<div class="theme-shape" style={themeCss(star, shape)}></div>{/each}
            {:else}
              <div class="theme-shape" style={themeCss(shape)}></div>
            {/if}
          {/each}
        {/if}
      </div>

      {#each browseTabs as tab (tab)}
        <Browse scene={sceneFor(tab, theme)} active={active === tab} blocked={!!current}
          {scale} {layout} onactivity={() => controller?.activity()} onselect={selectTile}
          onviewall={row => open({ type: 'grid', title: row.title, row })} />
      {/each}

      <div class="top-chrome" class:hidden={!chrome} inert={!!current || !chrome} aria-hidden={!!current || !chrome}>
        <div class="header-fade"></div>
        <div class="profile-header">
          <button class="profile" aria-label="Cameron profile" onclick={() => selectAccount('host', 'Cameron’s profile')}>
            <img class="profile-back" src={assets['ui/profile-back']} alt="" />
            <img class="avatar" src={assets['profile-avatar']} alt="" />
            <img class="profile-label" src={assets['ui/profile-label']} alt="" />
            <span class="learning-level">Kindergarten</span><span class="profile-name">Cameron</span>
          </button>
          <div class="account-controls">
            <button class="upgrade" onclick={() => selectAccount('upgrade', 'Upgrade')}>
              <img src={assets['ui/upgrade-crown']} alt="" />Upgrade
            </button>
            <button class="gems" aria-label="12 Gems" onclick={() => selectAccount('host', 'Gems')}>
              <img src={assets['ui/gems']} alt="" />12
            </button>
            <button class="parents" aria-label="Parents" onclick={() => selectAccount('host', 'Parents')}>
              <img src={assets['ui/parents']} alt="" />
            </button>
          </div>
        </div>
      </div>

      <div class="bottom-chrome" class:hidden={!chrome} inert={!!current || !chrome} aria-hidden={!!current || !chrome}>
        <div class="dock-fade"></div>
        <nav class="dock" aria-label="Main navigation">
          <img class="dock-shape" src={assets['ui/dock-' + dockTheme]} alt="" />
          {#each tabs as tab, i (tab)}
            <button class="dock-tab" class:selected={active === tab} style:left="{iconPositions[i]}%"
              aria-label={tab} aria-current={active === tab ? 'page' : undefined} onclick={() => selectTab(tab)}>
              <img src={assets['ui/dock-' + tab.toLowerCase() + '-' + (active === tab ? 'selected' : 'default')]} alt="" draggable="false" />
              {#if active === tab}<span>{tab}</span>{/if}
            </button>
          {/each}
        </nav>
      </div>

      {#each stack as page (page.key)}
        <div class="destination-layer" transition:fly={{
          x: page.type === 'content' ? 0 : layout.width,
          y: page.type === 'content' ? layout.height : 0,
          opacity: 1,
          duration: reduced ? 0 : MOTION.page,
          easing: cubicOut
        }}>
          <Destination destination={page} current={page === current} {layout} {scale} {reduced}
            phone={device === 'iPhone'} onback={back} onselect={selectTile} />
        </div>
      {/each}
    </div>
  </div>
</main>

<style>
  .shell { height: 100dvh; display: flex; flex-direction: column; background: #121329; color: #fff; }
  .toolbar { display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 8px 20px; padding: 10px 18px; background: #191a32; }
  .preview-title { display: flex; flex-wrap: wrap; align-items: baseline; gap: 6px 12px; }
  .preview-title strong { font-size: 14px; }
  .preview-title span { font-size: 11px; color: #c3c3d7; }
  .controls { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; }
  .controls label { display: inline-flex; align-items: center; gap: 6px; font-size: 11px; }
  .controls button, .controls select, .controls a { border: 1px solid #ffffff40; border-radius: 6px; color: white; background: #25263f; padding: 5px 9px; font-size: 11px; }
  .controls select { color-scheme: dark; }
  .controls a { text-decoration: none; }
  .controls a:hover { text-decoration: underline; }
  .canvas { flex: 1; min-height: 0; position: relative; overflow: hidden; display: flex; align-items: center; justify-content: center; }
  .canvas:fullscreen { background: #121329; width: 100vw; height: 100vh; }
  .device { flex: none; position: absolute; overflow: hidden; isolation: isolate; background: var(--scene-color); }
  .backdrop { position: absolute; inset: 0; overflow: hidden; pointer-events: none; }
  .theme-shape { position: absolute; border-radius: 50%; mix-blend-mode: soft-light; }
  .top-chrome, .bottom-chrome {
    position: absolute;
    inset: 0;
    pointer-events: none;
    z-index: 2;
    transition: transform 250ms ease-out;
  }
  .top-chrome.hidden { transform: translateY(calc(-1 * (var(--body) + 6px))); transition-duration: 200ms; }
  .bottom-chrome.hidden { transform: translateY(calc(var(--fade) + 20px)); transition-duration: 200ms; }
  .header-fade { position: absolute; inset: 0 0 auto; height: calc(var(--body) + 4px); background: linear-gradient(var(--scene-color), transparent); }
  .dock-fade { position: absolute; inset: auto 0 0; height: var(--fade); background: linear-gradient(to top, var(--scene-color) 20%, transparent); }
  .profile-header { position: absolute; inset: var(--top) var(--inset) auto; height: calc(100px * var(--head-scale)); display: flex; justify-content: space-between; }
  .profile {
    transform: scale(var(--head-scale));
    transform-origin: top left;
    width: 395px;
    height: 100px;
    border: 0;
    padding: 0;
    background: transparent;
    position: relative;
    pointer-events: auto;
    color: white;
    text-align: left;
    filter: drop-shadow(0 5px white);
  }
  .profile img { position: absolute; pointer-events: none; }
  .profile-back { left: 0; top: 0; }
  .profile-label { left: 101.25px; top: 2px; }
  .avatar { left: 0; top: 0; width: 159px; height: 100px; object-fit: contain; }
  .learning-level, .profile-name { position: absolute; left: 125px; white-space: nowrap; }
  .learning-level { top: 8px; font: 400 24px/36px Poppins, sans-serif; }
  .profile-name { top: 47px; font: 600 32px/48px Poppins, sans-serif; }
  .account-controls { display: flex; align-items: center; gap: 16px; height: 100px; transform: scale(var(--head-scale)); transform-origin: top right; }
  .account-controls button { pointer-events: auto; color: white; }
  .upgrade, .gems {
    height: 80px;
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 15px 16px;
    border: 2px solid #fff;
    border-radius: 25px;
    box-shadow: 0 5px white;
    font: 600 32px/1 Poppins, sans-serif;
  }
  .upgrade { background: #c84afb; }
  .gems { background: #4a2d80; }
  .parents { width: 85px; height: 80px; border: 0; background: none; padding: 0; }
  .account-controls img { display: block; }
  .dock {
    position: absolute;
    left: calc(50% - 400px);
    bottom: var(--dock-bottom);
    width: 800px;
    height: 150px;
    transform: scale(var(--dock-scale));
    transform-origin: center bottom;
    pointer-events: auto;
  }
  .dock-shape { position: absolute; inset: auto auto 0 0; transform: scaleX(1.041666667); transform-origin: left; pointer-events: none; }
  .dock-tab {
    position: absolute;
    bottom: 0;
    width: 132px;
    height: 150px;
    margin-left: -66px;
    background: none;
    border: 0;
    color: white;
    display: flex;
    justify-content: center;
    padding: 0;
  }
  .dock-tab img { position: absolute; top: 9px; pointer-events: none; }
  .dock-tab.selected img { top: -12px; }
  .dock-tab span { position: absolute; bottom: 5px; white-space: nowrap; font-size: calc(var(--label) / var(--dock-scale)); font-weight: 500; line-height: 1.5; }
  .destination-layer { position: absolute; inset: 0; z-index: 5; }
  @media (prefers-reduced-motion: reduce) { .top-chrome, .bottom-chrome { transition: none; } }
</style>
