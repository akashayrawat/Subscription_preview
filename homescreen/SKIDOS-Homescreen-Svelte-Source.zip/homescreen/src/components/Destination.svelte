<script>
  import { tick } from 'svelte';
  import Tile from './Tile.svelte';
  import assets from '../generated-assets.js';
  import { dragScroll, focusDialog, nearestFocus } from '../flow.js';
  import { bites, collectionFor, decorateTile } from '../catalog.js';

  let { destination, layout, scale, reduced, current, onback, onselect, phone } = $props();

  let carousel = $state();
  let previewIndex = $state(0);
  let biteIndex = $state(0);
  let subscriptionFrame = $state();
  const focusWidth = $derived(448 * layout.previewScale);
  const stride = $derived(focusWidth + layout.gap);
  const cards = $derived(destination.preview?.cards ?? []);
  const previewCard = $derived(cards[previewIndex]);
  const previewPoster = $derived(assets[previewCard?.poster ?? previewCard?.art ?? destination.preview?.poster]);
  const cell = $derived((layout.width - 2 * layout.inset - 3 * layout.gap) / 4);
  const backText = $derived(destination.type === 'content' ? 'Exit' : 'Back');

  $effect(() => {
    const index = destination.preview?.initial;
    const node = carousel;
    const step = stride;
    if (index === undefined || !node) return;
    // Preserve the selected position when switching device size.
    const target = node.dataset.initialized ? Number(node.dataset.focus) : index;
    node.dataset.initialized = 'true';
    previewIndex = target;
    void tick().then(() => { node.scrollLeft = target * step; });
  });

  function changePreview(direction) {
    const index = Math.min(cards.length - 1, Math.max(0, previewIndex + direction));
    carousel?.scrollTo({ left: index * stride, behavior: reduced ? 'instant' : 'smooth' });
  }

  function onkeydown(event) {
    if (!current || !carousel || !['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
    event.preventDefault();
    changePreview(event.key === 'ArrowLeft' ? -1 : 1);
  }

  function receiveMessage(event) {
    if (current && event.source === subscriptionFrame?.contentWindow &&
        event.origin === window.location.origin && event.data === 'skidos:subscription-back') onback();
  }
</script>

<svelte:window {onkeydown} onmessage={receiveMessage} />

<div class="destination" class:grid-page={destination.type === 'grid'}
  class:ip-page={destination.type === 'ip'} inert={!current}
  role="dialog" aria-modal={current} aria-label={destination.title} use:focusDialog>
  <button class="back" aria-label={backText} onclick={onback}>
    <img src={assets['ui/back-button']} alt="" />
    {#if backText === 'Exit'}<span>Exit</span>{/if}
  </button>
  {#if destination.type === 'ip'}
    {#if previewPoster}<img class="ip-poster" src={previewPoster} alt="" />{/if}
    <div class="ip-gradient"></div>
    {#if destination.preview.logo}
      <img class="ip-logo" src={assets[destination.preview.logo]} alt={destination.title} />
    {:else}
      <h1 class="ip-title">{destination.title}</h1>
    {/if}

    {#if cards.length}
      <div class="ip-carousel" bind:this={carousel} data-focus={previewIndex}
        style:--item-width="{focusWidth}px" style:--carousel-height="{420 * layout.previewScale + 16}px"
        use:dragScroll={{ scale: () => scale }}
        onscroll={() => previewIndex = nearestFocus(carousel.scrollLeft, stride, cards.length)}
        aria-label={destination.title + ' content'}>
        <div class="ip-track">
          {#each cards as card, i (card.id)}
            <div class="focus-slot" class:focused={previewIndex === i}>
              <Tile item={card} fitWidth={card.w * layout.previewScale} onclick={() => onselect(card)} />
              {#if previewIndex === i}<span class="focus-dot" aria-label="Focused preview"></span>{/if}
            </div>
          {/each}
        </div>
      </div>
    {/if}
  {:else if destination.type === 'grid'}
    <h1 class="grid-title">{destination.title}</h1>
    <div class="grid-scroll"><div class="grid">
      {#each collectionFor(destination.row) as card, i (i)}
        <Tile item={decorateTile(card)} fitWidth={cell} onclick={() => onselect(decorateTile(card))} />
      {/each}
    </div></div>
  {:else if destination.type === 'upgrade'}
    <iframe bind:this={subscriptionFrame} title="Subscription preview"
      src={'../?embedded=1&device=' + (phone ? 'phone' : 'tablet')}></iframe>
  {:else if destination.type === 'bites'}
    <section class="bites" aria-label="Short-video preview">
      <h1>SKIDOS Bites</h1>
      <Tile item={bites[biteIndex]} fitWidth={Math.min(layout.width * .40, layout.height * .65)}
        onclick={() => onselect(bites[biteIndex])} />
      <div class="bite-controls">
        <button disabled={biteIndex === 0} onclick={() => biteIndex--}>Previous</button>
        <button disabled={biteIndex === bites.length - 1} onclick={() => biteIndex++}>Next</button>
      </div>
    </section>
  {:else}
    <div class="entry">
      <h1>{destination.title}</h1>
      {#if destination.type === 'host'}<p>Opens in the SKIDOS app</p>{/if}
    </div>
  {/if}

</div>

<style>
  .destination { position: absolute; inset: 0; overflow: hidden; background: #4b2181; }
  .destination h1 { margin: 0; font-weight: 600; }
  .grid-page { background: #100d6b; }
  .back {
    position: absolute;
    z-index: 2;
    top: var(--top);
    left: var(--inset);
    padding: 0;
    border: 0;
    color: white;
    background: none;
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 600;
  }
  .back img { display: block; width: 46px; height: auto; }
  .grid-title {
    position: absolute;
    top: calc(var(--top) + 7px);
    left: calc(var(--inset) + 58px);
    font-size: calc(var(--row-title) + 3px);
  }
  .grid-scroll {
    position: absolute;
    inset: var(--body) 0 0;
    overflow-y: auto;
    scrollbar-width: none;
    overscroll-behavior: contain;
  }
  .grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    align-items: start;
    gap: var(--gap);
    padding: 0 var(--inset) calc(var(--inset) + 8px);
  }
  .ip-page { background: #cb347c; }
  .ip-poster { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; }
  .ip-gradient {
    position: absolute;
    inset: 58% 0 0;
    background: linear-gradient(to top, #cb347c 34.6%, #cb347c00);
    pointer-events: none;
  }
  .ip-logo, .ip-title {
    position: absolute;
    top: var(--top);
    right: var(--inset);
    max-width: 30%;
  }
  .ip-logo { max-height: calc(var(--body) - var(--top)); object-fit: contain; }
  .ip-title { text-align: right; font-size: var(--row-title); }
  .ip-carousel {
    position: absolute;
    inset: auto 0 var(--dock-bottom);
    height: var(--carousel-height);
    overflow-x: auto;
    overflow-y: hidden;
    scrollbar-width: none;
    overscroll-behavior-x: contain;
    scroll-snap-type: x proximity;
    cursor: grab;
  }
  .ip-track {
    display: flex;
    width: max-content;
    gap: var(--gap);
    padding: 15px calc((var(--device-width) - var(--item-width)) / 2) 0;
  }
  .focus-slot {
    width: var(--item-width);
    flex: none;
    scroll-snap-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
    transform: translateY(12px);
    transition: transform 240ms ease-out;
  }
  .focus-slot.focused { transform: translateY(0); }
  .focus-dot { width: 6px; height: 6px; border-radius: 50%; background: white; }
  .entry, .bites { position: absolute; inset: 0; display: grid; align-content: center; justify-items: center; gap: 12px; text-align: center; padding: 58px 24px 20px; }
  .entry p { margin: 0; font-size: 14px; }
  .bites h1 { font-size: 22px; }
  .bite-controls { display: flex; gap: 12px; }
  .bite-controls button { border: 1px solid white; color: white; background: transparent; padding: 4px 10px; border-radius: 6px; }
  .bite-controls button:disabled { opacity: .5; }
  iframe { display: block; width: 100%; height: 100%; border: 0; }
  @media (prefers-reduced-motion: reduce) { .focus-slot { transition: none; } }
</style>
