<script>
  import Tile from './Tile.svelte';
  import { dragScroll, rowItems } from '../flow.js';
  import { collectionFor, decorateTile } from '../catalog.js';

  let { scene, active, blocked, scale, layout, onactivity, onselect, onviewall } = $props();
  const viewAll = { id: 'view-all', kind: 'View All', status: 'None', w: 300, h: 300 };

  function visibleCards(row) {
    const { items, hasMore } = rowItems(collectionFor(row));
    const ipRow = items[0]?.kind === 'IP';
    return hasMore ? [...items, { ...viewAll, circle: ipRow }] : items;
  }
</script>

<section class="browse" class:active aria-label={scene.name} aria-hidden={!active}
  inert={!active || blocked} data-page={scene.key}
  onscroll={event => { if (event.target === event.currentTarget && active && !blocked) onactivity(); }}>
  <div class="page-content">
    {#each scene.rows as row (row.id)}
      <section aria-label={row.title}>
        <h2>{row.title}</h2>
        <div class="row-scroll" use:dragScroll={{scale: () => scale}} data-row={row.id}>
          <div class="track">
            {#each visibleCards(row) as card (card.id)}
              <Tile item={decorateTile(card)} fitWidth={card.w * layout.tileScale}
                onclick={() => card.kind === 'View All' ? onviewall(row) : onselect(decorateTile(card))} />
            {/each}
          </div>
        </div>
      </section>
    {/each}
  </div>
</section>

<style>
  .browse {
    position: absolute;
    inset: 0;
    overflow-x: hidden;
    overflow-y: auto;
    visibility: hidden;
    pointer-events: none;
    overscroll-behavior: contain;
    scrollbar-width: none;
  }
  .browse.active { visibility: visible; pointer-events: auto; }
  .page-content {
    padding: var(--body) 0 calc(var(--fade) + 20px);
    display: flex;
    flex-direction: column;
    gap: var(--row-gap);
  }
  h2 {
    font-size: var(--row-title);
    line-height: calc(var(--row-title) + 10px);
    font-weight: 600;
    margin: 0 var(--inset) 2px;
  }
  .row-scroll {
    overflow-x: auto;
    overflow-y: hidden;
    scrollbar-width: none;
    overscroll-behavior-x: contain;
    cursor: grab;
    scroll-padding-inline: var(--inset);
  }
  .track {
    display: flex;
    align-items: center;
    gap: var(--gap);
    width: max-content;
    min-width: 100%;
    padding: 8px var(--inset) 14px;
  }
  .row-scroll:global(.dragging) { cursor: grabbing; }
</style>
