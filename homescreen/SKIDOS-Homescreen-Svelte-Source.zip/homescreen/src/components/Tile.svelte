<script>
  import assets from '../generated-assets.js';
  import metrics from '../asset-metrics.json';
  let { item, onclick = () => {}, fitWidth } = $props();
  let fitScale = $derived(fitWidth ? fitWidth/item.w : 1);
  const badge = { Wifi: 'badge-wifi', Locked: 'badge-lock', Download: 'badge-download', Ad: 'badge-ad' };
  let label = $derived(item.label || item.title || ({ Show: 'Watch this show', Episode: 'Play this episode', IP: 'Explore character', 'IP Game': 'Play character game', 'IP Shows': 'Explore character shows', 'View All': 'View All' }[item.kind]) || 'Play this game');
  function bounds(id) { const m=metrics[id];return m?`left:${m.offsetX}px;top:${m.offsetY}px;width:${m.exportWidth}px;height:${m.exportHeight}px;right:auto;bottom:auto`:''; }
</script>

<div class="tile-frame" style:width="{item.w*fitScale}px" style:height="{item.h*fitScale}px">
<button style:--fit-scale={fitScale} class="tile" class:show={item.kind === 'Show'} class:episode={item.kind === 'Episode'} class:circle={item.kind === 'IP' || item.circle} class:banner={item.kind === 'IP Game' || item.kind === 'IP Shows'} class:view-all={item.kind === 'View All'} style:width="{item.w}px" style:height="{item.h}px" aria-label={label} title={label} {onclick} data-kind={item.kind} data-source={item.id}>
  {#if item.kind === 'View All'}
    <img class="view-arrow" src={assets['ui/view-all-arrow']} alt="" draggable="false" /><span class="view-label">View All</span>
  {:else if item.art === '13294:224791'}
    <div class="masha-composition"><img class="masha-circle" src={assets['masha-circle']} alt=""/><img class="masha-character" src={assets['masha-character']} alt=""/><div class="masha-gradient"></div><div class="masha-logo"><img src={assets['masha-logo']} alt="Masha & the Bear"/></div></div>
  {:else}
    <img class="artwork" src={assets[item.art]} alt="" draggable="false" style={bounds(item.art)} />
    {#if item.brand}<img class="brand-art" src={assets[item.brand]} alt="" draggable="false" style={bounds(item.brand)} />{/if}
    {#if item.kind === 'Game'}<span class="title-panel"><span>{item.title}</span></span>{/if}
    {#if item.kind === 'Show' || item.kind === 'Episode'}<img class="play-icon" src={assets['ui/play']} alt="" draggable="false" />{/if}
    {#if item.kind === 'Episode'}<span class="duration">{item.duration || '3:00'}</span>{/if}
    {#if badge[item.status]}<img class="badge" src={assets['ui/' + badge[item.status]]} alt={item.status === 'Wifi' ? 'Internet required while offline' : item.status} draggable="false" />{/if}
  {/if}
</button>
</div>

<style>
  .tile-frame{display:block;flex:none;position:relative}
  .tile{transform:scale(var(--fit-scale,1));transform-origin:top left;display:block;flex:none;position:relative;border:0;border-radius:30px;background:none;padding:0;cursor:pointer;color:#1a1a1a;overflow:visible;isolation:isolate;transition:filter 120ms,transform 120ms;outline-offset:8px;user-select:none}
  .tile:hover{filter:brightness(1.025)} .tile:focus-visible{outline:5px solid #ffe461}
  .artwork,.brand-art{position:absolute;display:block;inset:0;width:100%;height:100%;object-fit:fill;pointer-events:none;border-radius:30px}
  .brand-art{z-index:1}.circle,.circle .artwork{border-radius:9999px}
  .masha-composition{position:absolute;inset:0;border-radius:50%;overflow:hidden;pointer-events:none}.masha-circle{position:absolute;inset:0}.masha-character{position:absolute;left:43px;top:10px;width:163.54px;height:205.54px;object-fit:contain}.masha-gradient{position:absolute;left:2.5px;right:2.5px;bottom:5px;height:112.7px;background:linear-gradient(transparent,#ff9c1f 67.31%)}.masha-logo{position:absolute;left:48.24px;top:169.05px;width:166.586px;height:42.263px;overflow:hidden}.masha-logo img{position:absolute;width:100.25%;height:119.17%;left:-.13%;top:-19.17%}
  .title-panel{position:absolute;bottom:0;left:0;max-width:338px;height:70px;background:white;border-radius:0 50px 0 25px;padding:25px 20px 8px;display:flex;align-items:flex-start;box-sizing:border-box;z-index:2;overflow:hidden}
  .title-panel span{display:block;max-width:298px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;text-align:left;font:500 28px/1.1 Poppins,sans-serif}
  .play-icon{position:absolute;right:16px;bottom:16px;width:100px;height:100px;pointer-events:none;z-index:3}
  .episode .play-icon{left:calc(50% - 50px);top:calc(50% - 50px)}
  .episode::after{content:'';position:absolute;inset:0;border:5px solid white;border-radius:30px;pointer-events:none;z-index:2}
  .badge{position:absolute;top:0;right:0;width:70px;height:70px;z-index:4;pointer-events:none}
  .duration{position:absolute;bottom:0;left:0;height:70px;padding:25px 16px 0 35px;box-sizing:border-box;background:#fff;color:#4a2d80;border-radius:0 48px 0 25px;font:700 28px/1.1 Poppins,sans-serif;z-index:3}
  .view-all{background:#4b2181;border:5px solid #fff;display:flex;align-items:center;justify-content:center;box-sizing:border-box}
  .view-all.circle .view-label{position:absolute;inset:auto 0 25px;text-align:center;background:none;color:white;padding:0}
  .view-arrow{display:block;pointer-events:none}
  .view-label{position:absolute;left:-5px;bottom:-5px;background:#fff;color:#4b2181;border-radius:0 50px 0 25px;padding:25px 20px;font:700 28px/1.1 Nunito,Poppins,sans-serif;letter-spacing:-.28px}
  @media(prefers-reduced-motion:reduce){.tile{transition:none}}
</style>
