import reference from './scene.json';

export const tabs = ['Home', 'Play', 'Watch', 'Learn', 'Bites'];
export const themes = ['Morning', 'Afternoon', 'Evening', 'Night'];

export const devices = {
  iPhone: {
    width: 845, height: 390, inset: 16, gap: 12, rowGap: 14, title: 18,
    top: 12, body: 66, headerScale: .39, tileScale: .42, dockScale: .4,
    dockBottom: 14, fade: 90, label: 11, previewScale: .4505
  },
  iPad: {
    width: 1024, height: 768, inset: 28, gap: 18, rowGap: 18, title: 22,
    top: 24, body: 96, headerScale: .52, tileScale: .60, dockScale: .55,
    dockBottom: 20, fade: 120, label: 12, previewScale: .70
  }
};

const ipNames = {
  '13294:224653': 'Angry Birds',
  '13294:224791': 'Masha & the Bear',
  '13294:224798': 'Pinkfong',
  '13294:224806': 'Pocoyo',
  '13294:224814': 'SKIDOS',
  '13294:224832': 'The Smurfs',
  '13294:224840': 'SmileyWorld',
  '13294:226484': 'Pinkfong',
  '13294:226500': 'Millimages',
  '13294:226578': 'Masha & the Bear',
  '13294:226590': 'Masha & the Bear',
  '13294:226602': 'Masha & the Bear'
};

const homeRow = reference.scenes.Home.rows[0];
const watchRow = reference.scenes.Watch.rows[0];
const mashaShows = watchRow.cards.slice(1, 3);
const pinkfong = reference.scenes.IP.cards.map((card, index) => ({
  ...card,
  label: ['Baby Shark game', 'Baby Shark & Bebefinn', 'Pinkfong Dino World', 'Bebefinn'][index],
  poster: ['poster-babyshark', 'poster-babyshark', 'poster-dino', 'poster-babyfinn'][index]
}));

export const scenes = reference.scenes;
export const backgrounds = reference.backgrounds;
export const bites = reference.scenes.Watch.rows[3].cards.slice(0, 5);

export function decorateTile(card) {
  const ipName = ipNames[card.art];
  return ipName ? { ...card, label: ipName } : card;
}

export function previewFor(item) {
  const name = ipNames[item.art] ?? item.label;
  if (name === 'Pinkfong') return { name, logo: 'pinkfong-logo', cards: pinkfong, initial: 1 };
  if (name === 'Masha & the Bear') {
    const cards = mashaShows.map((card, index) => ({
      ...card,
      label: index === 0 ? 'Masha’s Nursery Rhymes' : 'Masha’s Spooky Stories'
    }));
    return { name, logo: 'masha-logo', cards, initial: 0 };
  }
  return { name, poster: item.art, cards: [], initial: 0 };
}

export function collectionFor(row) {
  return row === reference.scenes.Learn.rows[0] || row.id === reference.scenes.Learn.rows[0].id
    ? reference.scenes.Grid.cards
    : row.cards.filter(card => card.kind !== 'View All');
}

export function sceneFor(tab, theme) {
  const scene = scenes[tab];
  if (tab !== 'Home' || theme === 'Morning') return scene;
  // Rotate the available sample recommendations so theme changes can be reviewed offline.
  const offset = themes.indexOf(theme);
  return {
    ...scene,
    rows: [
      { ...homeRow, cards: [...homeRow.cards.slice(offset), ...homeRow.cards.slice(0, offset)] },
      ...scene.rows.slice(1)
    ]
  };
}
