import test from 'node:test';
import assert from 'node:assert/strict';
import { createChromeController, rowItems, nearestFocus } from '../src/flow.js';

function clock() {
  let now=0,id=0;const jobs=new Map();
  return {schedule(fn,ms){jobs.set(++id,{at:now+ms,fn});return id;},cancel(id){jobs.delete(id);},advance(ms){now+=ms;for(const [i,j]of jobs)if(j.at<=now){jobs.delete(i);j.fn();}},size(){return jobs.size;}};
}
test('controls return only two seconds after the final scroll, including momentum',()=>{
  const time=clock(),visible=[];const c=createChromeController({setVisible:v=>visible.push(v),schedule:time.schedule,cancel:time.cancel});
  c.activity();time.advance(1800);assert.deepEqual(visible,[false]);
  c.activity();time.advance(1999);assert.deepEqual(visible,[false,false]);
  time.advance(1);assert.deepEqual(visible,[false,false,true]);assert.equal(time.size(),0);
});
test('leaving or suspending a screen cancels its stale idle callback',()=>{
  const time=clock(),visible=[];const c=createChromeController({setVisible:v=>visible.push(v),schedule:time.schedule,cancel:time.cancel});
  c.activity();c.suspend();time.advance(10000);assert.deepEqual(visible,[false]);
  c.activity();assert.equal(time.size(),0);c.resume();assert.deepEqual(visible,[false,true]);
  c.activity();c.destroy();time.advance(2000);assert.deepEqual(visible,[false,true,false]);
});
test('row limit is independent of visible tile count',()=>{
  const a=Array.from({length:16},(_,i)=>i);
  assert.equal(rowItems(a.slice(0,15)).hasMore,false);
  assert.equal(rowItems(a).hasMore,true);assert.equal(rowItems(a).items.length,15);
  assert.equal(rowItems(a,7).items.length,7);assert.equal(rowItems(a,7).hasMore,true);
});
test('preview focus selects the nearest slot and clamps at both ends',()=>{
  assert.equal(nearestFocus(-50),0);assert.equal(nearestFocus(464),1);
  assert.equal(nearestFocus(900),2);assert.equal(nearestFocus(999999),3);
});
