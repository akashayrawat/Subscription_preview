import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { extname } from 'node:path';
import { bundlePreview } from '../preview-bundle.mjs';

const root = new URL('./', import.meta.url);
const types = { '.png': 'image/png', '.svg': 'image/svg+xml', '.ttf': 'font/ttf' };
const assetMap = JSON.parse(await readFile(new URL('assets/map.json', root), 'utf8'));

const embedded = await Promise.all(Object.entries(assetMap).map(async ([key, file]) => {
  const data = await readFile(new URL('assets/' + file, root));
  if (!data.length || !types[extname(file)]) throw new Error('Unreadable homescreen asset ' + file);
  return [key, 'data:' + types[extname(file)] + ';base64,' + data.toString('base64')];
}));

const assets = Object.fromEntries(embedded.filter(([key]) => !key.startsWith('font/')));
const fonts = Object.fromEntries(embedded.filter(([key]) => key.startsWith('font/')));
const fontCss = [400, 500, 600, 700].map(w => fontFace('Poppins', w, fonts['font/' + w]));
fontCss.push(fontFace('Nunito', 700, fonts['font/nunito']));

function fontFace(family, weight, source) {
  return `@font-face{font-family:${family};font-style:normal;font-weight:${weight};font-display:swap;src:url("${source}") format("truetype")}`;
}

const split = process.argv.includes('--split-assets');
const output = new URL('../dist/pages/homescreen/', root);
await mkdir(output, { recursive: true });
let assetTags = '';
if (split) {
  await writeFile(new URL('fonts.css', output), fontCss.join('\n'));
  assetTags += '<link rel="stylesheet" href="./fonts.css">';
  let chunk = {};
  let chunkSize = 0;
  let chunkNumber = 0;
  async function flushChunk() {
    if (!chunkSize) return;
    const file = 'assets-' + ++chunkNumber + '.js';
    const source = 'Object.assign(window.skidosHomescreenAssets ??= {}, ' + JSON.stringify(chunk) + ');';
    await writeFile(new URL(file, output), source);
    assetTags += '<script src="./' + file + '"></script>';
    chunk = {};
    chunkSize = 0;
  }
  for (const [key, value] of Object.entries(assets)) {
    if (chunkSize && chunkSize + value.length > 8_000_000) await flushChunk();
    chunk[key] = value;
    chunkSize += value.length;
  }
  await flushChunk();
}
const script = await bundlePreview(root, assets, { externalAssets: split });
const html = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="color-scheme" content="dark"><title>SKIDOS Homescreen Preview</title>${assetTags}<style>
${split ? '' : fontCss.join('')}
*{box-sizing:border-box}html,body{margin:0;min-height:100%;background:#121329}body{font-family:Poppins,sans-serif}
button,select{font:inherit}button{cursor:pointer;touch-action:manipulation}
button:focus-visible,select:focus-visible,a:focus-visible{outline:2px solid #ffe461;outline-offset:3px}
</style></head><body><div id="app"></div><script>${script}</script></body></html>`;

await writeFile(new URL('index.html', output), html);
console.log('Built landscape homescreen preview for /homescreen/.');
