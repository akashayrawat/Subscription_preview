# SKIDOS homescreen preview source

This archive contains the editable Svelte homescreen source for the SKIDOS preview.

```sh
npm ci
npm run build
npm test
```

The build creates `dist/pages/homescreen/index.html`. For GitHub's web uploader, run `npm run build -- --split-assets` and publish the generated HTML, CSS, and asset bundles under `homescreen/`. The published preview opens the subscription preview from the parent directory. Use the parent site and the generated homescreen together to test Upgrade navigation.

[Live homescreen](https://akashayrawat.github.io/Subscription_preview/homescreen/) · [Landscape design handoff](https://www.figma.com/design/jwlGWH16A0EpOXJyJj6JYB/SKIDOS_workspace?node-id=13575-268878)
