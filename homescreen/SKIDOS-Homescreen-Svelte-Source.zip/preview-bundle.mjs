import { build } from 'esbuild';
import { compile } from 'svelte/compiler';
import { readFile } from 'node:fs/promises';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

export async function bundlePreview(root, assets, { externalAssets = false } = {}) {
  const result = await build({
    absWorkingDir: fileURLToPath(root),
    entryPoints: ['src/main.js'],
    bundle: true,
    write: false,
    format: 'iife',
    platform: 'browser',
    conditions: ['browser', 'svelte'],
    target: ['es2022'],
    minify: true,
    plugins: [{
      name: 'local-svelte-preview',
      setup(builder) {
        builder.onResolve({ filter: /generated-assets\.js$/ }, () => ({ path: 'assets', namespace: 'embedded-assets' }));
        builder.onLoad({ filter: /.*/, namespace: 'embedded-assets' }, () => ({
          contents: externalAssets
            ? 'export default window.skidosHomescreenAssets'
            : 'export default ' + JSON.stringify(assets),
          loader: 'js'
        }));
        builder.onLoad({ filter: /\.svelte$/ }, async ({ path }) => {
          const output = compile(await readFile(path, 'utf8'), { filename: path, generate: 'client', css: 'injected' });
          return {
            contents: output.js.code,
            loader: 'js',
            resolveDir: dirname(path),
            warnings: output.warnings.map(warning => ({ text: path + ': ' + warning.message }))
          };
        });
      }
    }]
  });
  return result.outputFiles[0].text.replaceAll('</script', '<\\/script');
}
